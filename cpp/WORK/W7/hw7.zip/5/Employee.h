#pragma once
#include <string>
#include <iostream>

using namespace std;

class Employee
{
public:
	string name;
	string position;
	int salary;

	void showInfoEmployee();
};


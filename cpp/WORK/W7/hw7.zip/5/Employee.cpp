#include "Employee.h"

void Employee::showInfoEmployee()
{
	cout << "Name: " << this->name << endl;
	cout << "Position: " << this->position << endl;
	cout << "Salary: " << this->salary << endl;
}

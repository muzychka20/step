#include "Manager.h"

void Manager::managmentOfSubordinates()
{	
	cout << "I can command!" << endl;
}

void Manager::managmentOfBonusSystem()
{
	cout << "I can change bonus!" << endl;
}

#include "Vehicle.h"

void Vehicle::showInfoVehicle()
{
	cout << "Color: " << this->color << endl;
	cout << "Max speed: " << this->maxSpeed << endl;
}

#pragma once
#include <string>
#include <iostream>

using namespace std;

class Vehicle
{
public:
	int maxSpeed;
	string color;

	void showInfoVehicle();
};


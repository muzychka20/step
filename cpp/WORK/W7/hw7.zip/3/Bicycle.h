#pragma once
#include "Vehicle.h"

class Bicycle : public Vehicle
{
public:
	int numberOfSpeeds;

	void showBicycleInfo();
};


#pragma once
#include <string>
#include <iostream>

using namespace std;

class Product
{
public:
	string name;
	int price;

	void showProductInfo();
};


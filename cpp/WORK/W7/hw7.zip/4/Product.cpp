#include "Product.h"

void Product::showProductInfo()
{
	cout << "Name: " << this->name << endl;
	cout << "Price: " << this->price << endl;
}

#include "Student.h"

void Student::showStudentInfo()
{
	cout << "Name: " << this->name << endl;
	cout << "Age: " << this->age << endl;
	cout << "Student number: " << this->studentNumberID << endl;
}

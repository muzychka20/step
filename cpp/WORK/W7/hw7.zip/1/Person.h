#pragma once
#include <string>

using namespace std;

class Person
{
public:
	string name;
	int age;
};


#pragma once
#include "Book.h"

class EBook : public Book
{
public:
	string format;

	void showEBookInfo();
};


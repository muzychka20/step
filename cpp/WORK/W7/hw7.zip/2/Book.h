#pragma once
#include <string>
#include <iostream>

using namespace std;

class Book
{
public:
	string title;
	string author;
	int price;
};